﻿using System;
using System.Collections.Generic;
using System.IO;


namespace Algorithms_Assesment1_Ellie
{
    class Program
    {
        
        
            static void Main(string[] args)
            {

            Console.ForegroundColor = ConsoleColor.White;


                Console.WriteLine("Would you like to work with Road 1 (1), Road 2 (2) or Road 3 (3) or Merge between road 1 + 3 (4)"); //This is the road selection

                int answer = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Would you like to work with the 256  (1) 2048 (2) version?"); //This is the selection for the data size choice

                int numAns = Convert.ToInt32(Console.ReadLine());
                // this allows to user to select what road they want and what size road to use



                string[] Road = new string[255]; //This makes an array called road for all the data in road although it says 255 its actualy 256 as it starts from 0
    ;
                

            if (numAns == 2)
                {
                    Array.Resize(ref Road, 2047); //If 2047 is chosen the original array is made bigger
                }
            else
            {
                Console.WriteLine("You have entered an invalid choice"); //This is validation to ensure a  valid choice is entered
            }



            do //Do is used to execute the series of statements that will load the right txt file bassed on user input
            {
                if (numAns == 1)
                {
                    if (answer == 1)
                    {
                        Road = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_1_256.txt");//This is the file path for road one this will need to be changed for each user
                    }
                    else if (answer == 2)
                    {
                        Road = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_2_256.txt");

                    }
                    else if (answer == 3)
                    {
                        Road = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_3_256.txt");
                    }
                    else if (answer == 4) //This was where I attempeted to merge 2 files into one file then add the merged file to the array
                    {
                        string[] f1 = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_1_256.txt");
                        string[] f2 = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_2_256.txt");

                        using (StreamWriter sw = File.CreateText(@"C:\Users\Student\Desktop\Merge.txt"))
                        {
                            for (int i = 0; i < f1.Length || i < f2.Length; i++)
                            {
                                if (i < f1.Length)
                                    sw.WriteLine(f1[i]);
                                if (i < f2.Length)
                                    sw.WriteLine(f2[i]);

                            }
                    
                        Road = File.ReadAllLines(@"C:\Users\Student\Desktop\Merge.txt"); //This is where I tried to add the merged file to the array
                        }
                    }
                    
                    else
                    {
                        Console.WriteLine("You have entered an invalid choice "); 

                    }
                }
                else if (numAns == 2) // This is the statement block for the 2047 sized files
                {
                    if (answer == 1)
                    {
                        Road = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_1_2048.txt");
                    }
                    else if (answer == 2)
                    {
                        Road = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_2_2048.txt");

                    }
                    else if (answer == 3)
                    {
                        Road = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_3_2048.txt");
                    }
                    else
                    {
                        Console.WriteLine("You have entered a value that is not 1, 2 or 3. Please enter one of these values");

                    }
                }
            } while (answer != 1 && answer != 2 && answer != 3); // The while is needed to break the do loop
                


                int[] IntRoad = Array.ConvertAll(Road, int.Parse);
                //As the array (road) is a string this converts it to a number array that can be understood by the algorithm

                int sortCount = 0; //Counter to count the amount of sorts

                Console.WriteLine("Would you like to use , Bubble Sort (1), Quick Sort (2) or Selection Sort (3) insertion Sort (4)");
                int sortChoice = Convert.ToInt32(Console.ReadLine());
                //This lets the user choose an algorithm of their choice
                if (sortChoice == 1)
                {
                    BubbleSort(ref IntRoad, ref sortCount); //When the user selects an algorithm the algorithm method is called
                }
                else if (sortChoice == 2)
                {

                    QuickSort(ref IntRoad, ref sortCount);
                }
                else if (sortChoice == 3)
                {
                    SelectionSort(ref IntRoad, ref sortCount);
                }
                else if (sortChoice == 4)
                {
                    InsertionSort(ref IntRoad, ref sortCount);
                }

                int[] DescNetInt = new int[255]; //Define a new array that will store the data in descending order
                if (numAns == 2)
                {
                    Array.Resize(ref DescNetInt, 2047); //The array needs to be big enough to hold all 2047 data sets
                }
                CreateDescendingList(IntRoad, ref DescNetInt);
                //Creates method that references the decending array made previously

                DisplayValues(IntRoad, DescNetInt, numAns);
            //This is to call the method that will display the 10th digit of the ordered array
                Console.WriteLine("");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine($"This sort took {sortCount} steps");
                Console.ForegroundColor = ConsoleColor.White;
                //This will say the amount of steps it took to sort the data



                Console.WriteLine("Enter a value you would like to find in the array");
                int SearchValue = Convert.ToInt32(Console.ReadLine()); //This converts the input into a integer that can be handled by the 
                //You can enter the value you wish to find 
                int searchCount = 0;//counts the amount of steps in a search
                List<int> foundPositions = new List<int>();
                //this list will hold all the positions that contain the number being searched for.
                Console.WriteLine("would you like to use Linear Search (1) or Binary Search (2)?");
                int choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    LinearSearch(IntRoad, SearchValue, ref foundPositions, ref searchCount);
                    //This calls the linear search method
                }
                else if (choice == 2)
                {
                    bool found = false;
                    int closest = RecursiveBinary(IntRoad, SearchValue, 0, IntRoad.Length - 1, ((IntRoad.Length - 1) / 2), ref found, ref foundPositions, ref searchCount);
                    //this calls the binary search method and displays the values
                    if (foundPositions.Count > 0)
                    {
                        
                        Console.WriteLine("Input integer has been found in the list at the following positions;");
                        for (int x = 0; x < foundPositions.Count; x++)
                        {
                            Console.WriteLine(foundPositions[x]);
                        }
                    }
                    else
                    {
                        Console.WriteLine("(Keep in mind the list starts at 0)");
                        Console.WriteLine($"Value not found, closest value is {IntRoad[closest]} at position {closest}");
                    }
                }
                Console.WriteLine("");
                Console.WriteLine($"The search algorithm took {searchCount} amount of steps");




            }

            public static void QuickSort(ref int[] data, ref int count)
            {
                QuickSort(ref data, 0, data.Length - 1, ref count);
                //This would fill in the parameters 
            }

            public static void QuickSort(ref int[] data, int left, int right, ref int count)
            {
                int l = left;
                int r = right;
                int pivot = data[(left + right) / 2]; //This finds the midpoint
                int temp;
              
                do
                {


                    while ((data[l] < pivot) && (l< right))
                    {
                        l++;
                        //This sees is the most left digit is smaller than the pivot if so go to next value
                    }
                    while ((pivot < data[r]) && (r > left))
                    {
                        r--;
                        // This does the same thing as aboive but for the value on the right 
                    }

                    if (l <= r)
                    {
                        temp = data[l];
                        data[l] = data[l];
                        data[l] = temp;
                        l++;
                        r--;

                        //This uses the checked values above to order the data using the temp variable
                    }
                    count++;
                } while (l <= r); //Because we used do we need while to break it

                if (left < r)
                {
                    QuickSort(ref data, left, r, ref count);
                }
                if (l < right)
                {
                    QuickSort(ref data, l, right, ref count);
                }
                //Continues to call the function until the data is sorted

            }
            public static void CreateDescendingList(int[] array, ref int[] OutputArray)
            {

                for (int x = 0; x < array.Length - 1; x++)
                {
                    OutputArray[x] = array[((array.Length - 1) - x)];
                }
                //This uses the recently made array and makes a new array in the reverse order 
            }

        public static void DisplayValues(int[] ascArray, int[] descArray, int vAns)
        {
            if (vAns == 1)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("The log sorted in ascending order, displaying every tenth item");
                Console.ForegroundColor = ConsoleColor.White;
                for (int x = 0; x < ascArray.Length; x += 10)
                {
                    Console.Write(ascArray[x] + ", ");
                }
                Console.WriteLine("");

                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("The log sorted in descending order, displaying every tenth item");
                Console.ForegroundColor = ConsoleColor.White;
                for (int x = 0; x < descArray.Length; x += 10)
                {
                    Console.Write(descArray[x] + ",");
                }
            }
            else if (vAns == 2)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("The log sorted in ascending order, displaying every 50th item");
                Console.ForegroundColor = ConsoleColor.White;

                for (int x = 0; x < ascArray.Length; x += 50)
                {
                    Console.Write(ascArray[x] + ",");
                }
                Console.WriteLine("");
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("The log sorted in descending order, displaying every 50th item");
                Console.ForegroundColor = ConsoleColor.White;
                for (int x = 0; x < descArray.Length; x += 50) // For loop which will print the 50th item for the lenght of the array
                {
                    Console.Write(descArray[x] + ",");
                }

            }
        }




            public static void LinearSearch(int[] array, int ItemSearchedFor, ref List<int> foundPositions, ref int count)
            {
                int currentValue = 0;
                int MaxValue = array.Length;
                bool MoreOrLess = false;
                int closestValue = 0;
                int closestLocation = 0;
                int NoFound = 0;
                //declares the required variables
                do
                {
                    count++;//counter tick
                    if (array[currentValue] == ItemSearchedFor)
                    {
                        foundPositions.Add(currentValue);
                        NoFound++;
                        currentValue += 1;
                        //if the current integer is the same as the one requested by user the position of the ingeger is put on a list
                    }
                    else
                    {
                        if (MoreOrLess == false && array[currentValue] > ItemSearchedFor)
                        {
                            MoreOrLess = true;
                            //this checks if the value has been passed yet.
                            if ((array[currentValue] - ItemSearchedFor) < (ItemSearchedFor - array[(currentValue - 1)]))
                            {
                                closestValue = array[currentValue];
                                closestLocation = currentValue;

                            }
                            else
                            {
                                closestValue = array[(currentValue - 1)];
                                closestLocation = (currentValue - 1);
                            }
                            //this checks if the closest value to the searched item is the value lower or the value higher.
                        }
                        currentValue += 1;
                    }

                } while (currentValue < MaxValue);

                if (foundPositions.Count > 0)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Input integer has been found in the list at the following positions;");
                    for (int x = 0; x < foundPositions.Count; x++)
                    {
                        Console.WriteLine(foundPositions[x]);
                    }
                    //this lists the positions of the searched value
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Input integer has not been found in the list");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine($"Your closest value is {closestValue} and is in location {closestLocation}");
                    //this displays the closest value to the searched value, if the value is not in the array.
                }

            }

            public static int RecursiveBinary(int[] array, int ItemSearchedFor, int min, int max, int midpoint, ref bool found, ref List<int> FoundPositions, ref int count)
            {
                count++;
                //ticks the counter
                if (min > max)
                {
                    found = false;
                    return midpoint;
                    //this is the base case if the value is not in the array
                }
                else
                {
                    midpoint = (max + min) / 2;

                    if (ItemSearchedFor == array[midpoint])
                    {
                        found = true;
                        FoundPositions.Add(midpoint);
                        CheckLeft(array, midpoint, ref FoundPositions);
                        CheckRight(array, midpoint, ref FoundPositions);
                        return midpoint;
                        //this is the base case if the value is found, this code then calls methods to check both sides of the selected value to see if the variable being searched for is duplicated
                    }
                    else if (ItemSearchedFor < array[midpoint])
                    {
                        return RecursiveBinary(array, ItemSearchedFor, min, midpoint - 1, ((min + (midpoint - 1)) / 2), ref found, ref FoundPositions, ref count);
                        //this recursively calls the method with the max value being shifted down to the value below the midpoint, as the value being searched fo rhas to be in the lower half.
                    }
                    else
                    {
                        return RecursiveBinary(array, ItemSearchedFor, midpoint + 1, max, (((midpoint + 1) + max) / 2), ref found, ref FoundPositions, ref count);
                        //this recursively calls the method with the max value being shifted down to the value below the midpoint, as the value being searched fo rhas to be in the lower half.

                    }
                }


            }

            public static int CheckLeft(int[] array, int midpoint, ref List<int> FoundPositions)
            {
                if (array[midpoint] == array[midpoint - 1])
                {
                    FoundPositions.Add(midpoint - 1);
                    CheckLeft(array, (midpoint - 1), ref FoundPositions);
                }
                return -1;
                //this method checks the values to the left of the found variable in the binary search to see if the found value has multiple elements in the array to the left of the selected array
            }

            public static int CheckRight(int[] array, int midpoint, ref List<int> FoundPositions)
            {
                if (array[midpoint] == array[midpoint + 1])
                {
                    FoundPositions.Add(midpoint + 1);
                    CheckRight(array, (midpoint + 1), ref FoundPositions); 
                }
                return -1;
                //this method checks the values to the right of the found variable in the binary search to see if the found value has multiple elements in the array to the right of the selected array 
            }

            public static void BubbleSort(ref int[] array, ref int count) //This is the bubble sort method
            {
                int temp; //This will be a tempory integer to store the current integer before it is swapped
                for (int a = 0; a < array.Length - 1; a++)
                {
                    //the code bellow will execute for each value within the array
                    for (int b = 0; b < array.Length - 1; b++) //this refers to the position in the array
                    {
                        //the following code will execute for each value in the array
                        count++;
                        if (array[b] > array[b + 1])  
                        {
                            temp = array[b + 1]; 
                            array[b + 1] = array[b];
                            array[b] = temp;
                            
                        }
                    } //If the curent possition is higher than the position + one space , the integers are swapped, this continues until the data is ordered low to high
                }

            }

            public static void InsertionSort(ref int[] array, ref int count)
            {

                for (int x = 1; x < array.Length; x++)
                {
                    int key = array[x];
                    int y = x - 1;
                    //this declares required variables

                    while (y >= 0 && array[y] > key)
                    {
                        count++;
                        array[y + 1] = array[y];
                        y = y - 1;
                        //this moves the selected variable down the array if the selected variable is less than the ones behind it
                    }
                    array[y + 1] = key;
                }
            }

            public static void SelectionSort(ref int[] array, ref int count)
            {
                for (int x = 0; x < array.Length - 1; x++)
                {
                    int min = x;
                    for (int y = 0; y < array.Length - 1; y++)
                    {
                        count++;
                        if (array[y] > array[min])
                        {
                            min = y;
                            SwapSelection(ref array[x], ref array[min]);
                            //checks to see if the value selected is larger than the currently smallest value, if it is, moves the minimum to this new value then calls the swapping method
                        }
                    }
                }

            }

            public static void SwapSelection(ref int i, ref int j)
            {
                int temp = i;
                i = j;
                j = temp;
                //this submethod does the swapping function for the selection swap method
            }
        //public static void merge()
        //{
        //    string[] f1 = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_1_256.txt");
        //    string[] f2 = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_2_256.txt");

        //    using (StreamWriter sw = File.CreateText(@"C:\Users\Student\Desktop\Merge.txt"))
        //    {
        //        for (int i = 0; i < f1.Length || i < f2.Length; i++)
        //        {
        //            if (i < f1.Length)
        //                sw.WriteLine(f1[i]);
        //            if (i < f2.Length)
        //                sw.WriteLine(f2[i]);

        //        }
        //        string[] road = new string[255];
        //        road = File.ReadAllLines(@"C:\Users\Student\Desktop\Road_1_256.txt");
        //    }
        //}
          

    }

        
}

   

